package com.example.tomasiak_inventoryapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private EditText editItemName;
    private EditText editQuantity;

    private Button buttonSaveItem;
    private Button buttonCancel;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        editItemName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editQuantity);

        buttonSaveItem = findViewById(R.id.buttonSaveItem);
        buttonCancel = findViewById(R.id.buttonCancel);

        databaseHelper = new DatabaseHelper(this);

        buttonSaveItem.setOnClickListener(v -> saveItem());

        buttonCancel.setOnClickListener(v -> finish());
    }

    private void saveItem() {

        String itemName = editItemName.getText().toString().trim();
        String quantityText = editQuantity.getText().toString().trim();

        if (itemName.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter an item name and quantity.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        int quantity;

        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(
                    this,
                    "Please enter a valid quantity.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        if (quantity < 0) {
            Toast.makeText(
                    this,
                    "Quantity cannot be negative.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        long result = databaseHelper.addItem(itemName, quantity);

        if (result != -1) {

            Toast.makeText(
                    this,
                    "Item added successfully.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

        } else {

            Toast.makeText(
                    this,
                    "Unable to add item.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}