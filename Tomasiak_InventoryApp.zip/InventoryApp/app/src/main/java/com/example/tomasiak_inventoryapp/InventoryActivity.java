package com.example.tomasiak_inventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    private LinearLayout inventoryContainer;
    private Button buttonAddItem;
    private Button buttonNotifications;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        inventoryContainer = findViewById(R.id.inventoryContainer);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonNotifications = findViewById(R.id.buttonNotifications);

        databaseHelper = new DatabaseHelper(this);

        buttonAddItem.setOnClickListener(v -> {
            Intent intent = new Intent(
                    InventoryActivity.this,
                    AddItemActivity.class
            );
            startActivity(intent);
        });

        buttonNotifications.setOnClickListener(v -> {
            Intent intent = new Intent(
                    InventoryActivity.this,
                    NotificationActivity.class
            );
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Refresh inventory every time this screen becomes visible.
        loadInventory();
    }

    private void loadInventory() {

        // Remove old rows before loading the latest database contents.
        inventoryContainer.removeAllViews();

        Cursor cursor = databaseHelper.getAllItems();

        while (cursor.moveToNext()) {

            int itemId =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow("id")
                    );

            String itemName =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow("item_name")
                    );

            int quantity =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow("quantity")
                    );

            createInventoryRow(itemId, itemName, quantity);
        }

        cursor.close();
    }

    private void createInventoryRow(
            int itemId,
            String itemName,
            int quantity) {

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(8, 8, 8, 8);

        // Item name
        TextView itemNameText = new TextView(this);
        itemNameText.setText(itemName);

        LinearLayout.LayoutParams nameParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        2.5f
                );

        itemNameText.setLayoutParams(nameParams);

        // Quantity
        TextView quantityText = new TextView(this);
        quantityText.setText(String.valueOf(quantity));

        LinearLayout.LayoutParams quantityParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        0.8f
                );

        quantityText.setLayoutParams(quantityParams);

        // Action area
        LinearLayout actionLayout = new LinearLayout(this);
        actionLayout.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout.LayoutParams actionParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        3.2f
                );

        actionLayout.setLayoutParams(actionParams);

        Button decreaseButton = new Button(
                this,
                null,
                android.R.attr.buttonBarButtonStyle
        );
        decreaseButton.setText("-");
        decreaseButton.setTag(itemId);

        Button increaseButton = new Button(
                this,
                null,
                android.R.attr.buttonBarButtonStyle
        );
        increaseButton.setText("+");
        increaseButton.setTag(itemId);

        Button deleteButton = new Button(
                this,
                null,
                android.R.attr.buttonBarButtonStyle
        );
        deleteButton.setText("Del");
        deleteButton.setTag(itemId);

        increaseButton.setOnClickListener(v -> {
            int newQuantity = quantity + 1;

            if (databaseHelper.updateQuantity(itemId, newQuantity)) {
                loadInventory();
            }
        });

        decreaseButton.setOnClickListener(v -> {

            int newQuantity = quantity - 1;

            if (newQuantity < 0) {
                newQuantity = 0;
            }

            if (databaseHelper.updateQuantity(itemId, newQuantity)) {

                if (newQuantity == 0 && quantity > 0) {
                    sendLowInventoryAlert(itemName);
                }

                loadInventory();
            }
        });

        deleteButton.setOnClickListener(v -> {
            if (databaseHelper.deleteItem(itemId)) {
                loadInventory();
            }
        });

        actionLayout.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);

        LinearLayout.LayoutParams smallButtonParams =
                new LinearLayout.LayoutParams(
                        dpToPx(44),
                        dpToPx(48)
                );

        LinearLayout.LayoutParams deleteButtonParams =
                new LinearLayout.LayoutParams(
                        dpToPx(64),
                        dpToPx(48)
                );

        decreaseButton.setLayoutParams(smallButtonParams);
        increaseButton.setLayoutParams(smallButtonParams);
        deleteButton.setLayoutParams(deleteButtonParams);

        actionLayout.addView(decreaseButton);
        actionLayout.addView(increaseButton);
        actionLayout.addView(deleteButton);

        row.addView(itemNameText);
        row.addView(quantityText);
        row.addView(actionLayout);

        inventoryContainer.addView(row);
    }

    private void sendLowInventoryAlert(String itemName) {

        SharedPreferences preferences =
                getSharedPreferences(
                        "InventoryPreferences",
                        MODE_PRIVATE
                );

        boolean smsEnabled =
                preferences.getBoolean("sms_enabled", false);

        String phoneNumber =
                preferences.getString("phone_number", "");

        if (!smsEnabled || phoneNumber.isEmpty()) {
            return;
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            return;
        }

        try {

            SmsManager smsManager = SmsManager.getDefault();

            String message =
                    "Inventory Alert: "
                            + itemName
                            + " has reached zero stock.";

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "Low inventory SMS sent.",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Unable to send SMS.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    //Helper
    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}