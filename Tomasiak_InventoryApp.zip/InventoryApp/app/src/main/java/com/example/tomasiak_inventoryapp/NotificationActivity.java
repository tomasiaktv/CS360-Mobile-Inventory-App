package com.example.tomasiak_inventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class NotificationActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private EditText editPhoneNumber;
    private TextView textPermissionStatus;

    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        textPermissionStatus = findViewById(R.id.textPermissionStatus);

        Button buttonEnableSms = findViewById(R.id.buttonEnableSms);
        Button buttonDenySms = findViewById(R.id.buttonDenySms);
        Button buttonBack = findViewById(R.id.buttonNotificationBack);

        preferences = getSharedPreferences(
                "InventoryPreferences",
                MODE_PRIVATE
        );

        // Restore previously saved phone number.
        String savedPhoneNumber =
                preferences.getString("phone_number", "");

        editPhoneNumber.setText(savedPhoneNumber);

        updatePermissionStatus();

        buttonEnableSms.setOnClickListener(v -> enableSmsNotifications());

        buttonDenySms.setOnClickListener(v -> {
            preferences.edit()
                    .putBoolean("sms_enabled", false)
                    .apply();

            textPermissionStatus.setText(
                    "SMS notifications are currently disabled."
            );
        });

        buttonBack.setOnClickListener(v -> finish());
    }

    private void enableSmsNotifications() {

        String phoneNumber =
                editPhoneNumber.getText().toString().trim();

        if (phoneNumber.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter a phone number.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Save the number so InventoryActivity can use it later.
        preferences.edit()
                .putString("phone_number", phoneNumber)
                .apply();

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            preferences.edit()
                    .putBoolean("sms_enabled", true)
                    .apply();

            updatePermissionStatus();

        } else {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0
                    && grantResults[0]
                    == PackageManager.PERMISSION_GRANTED) {

                preferences.edit()
                        .putBoolean("sms_enabled", true)
                        .apply();

                Toast.makeText(
                        this,
                        "SMS notifications enabled.",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                preferences.edit()
                        .putBoolean("sms_enabled", false)
                        .apply();

                Toast.makeText(
                        this,
                        "SMS permission denied. The app will continue without notifications.",
                        Toast.LENGTH_LONG
                ).show();
            }

            updatePermissionStatus();
        }
    }

    private void updatePermissionStatus() {

        boolean enabled =
                preferences.getBoolean("sms_enabled", false);

        if (enabled) {
            textPermissionStatus.setText(
                    "SMS notifications are currently enabled."
            );
        } else {
            textPermissionStatus.setText(
                    "SMS notifications are currently disabled."
            );
        }
    }
}